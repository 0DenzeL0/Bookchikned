from app import app
import os

basedir = os.path.abspath(os.path.dirname(__file__))
DATABASE = os.path.join(basedir, 'app.db')

MAX_CONTENT_LENGTH = 1024 * 1024  # Максимальный размер полей

UPLOADS_DEFAULT_DEST = os.path.join(basedir, 'upload/')  # Сюда заружаются аватары пользователей

SQLALCHEMY_DATABASE_URI = 'sqlite:///' + DATABASE  # База данных

SECRET_KEY = 'you-will-never-guess'

FLASKY_ADMIN = 'root@gmail.com'  # Администратор сайта(может удалять, изменять информацию на сайте). Пароль: password

SQLALCHEMY_TRACK_MODIFICATIONS = False

if __name__ == '__main__':
    app.run(debug=True, host='127.0.0.1')
