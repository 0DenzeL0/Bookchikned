from . import book, auth, comment, log, user, main
from ..decorators import permission_required, admin_required
from flask import render_template, url_for, flash, redirect, request, abort
from flask_login import login_required, current_user, login_user, logout_user
from app.models import User, Log, Permission, Book, Comment
from .forms import EditProfileForm, AvatarUploadForm, LoginForm, RegistrationForm, ChangePasswordForm, \
    SearchForm, EditBookForm, AddBookForm, CommentForm
from app import db, avatars
import json


@auth.route('/login/', methods=['GET', 'POST'])
def login():  # Обработка авторизации пользователя
    login_form = LoginForm()
    if login_form.validate_on_submit():
        the_user = User.query.filter(User.email.ilike(login_form.email.data)).first()
        if the_user is not None and the_user.verify_password(login_form.password.data):
            login_user(the_user, login_form.remember_me.data)
            flash(u'Вы авторизовались, ' + the_user.name + '!', 'success')
            return redirect(request.args.get('next') or url_for('main.index'))
        flash(u'Неверное имя пользователя или пароль!', 'danger')
    return render_template("login.html", form=login_form, title=u"Войти")


@auth.route('/logout/')
@login_required
def logout():  # Обработка выхода из аккаунта
    logout_user()
    flash(u'Вы вышли из системы', 'info')
    return redirect(url_for('main.index'))


@auth.route('/register/', methods=['GET', 'POST'])
def register():  # Обработка регистрации пользователя
    form = RegistrationForm()
    if form.validate_on_submit():
        the_user = User(email=form.email.data,
                        name=form.name.data,
                        password=form.password.data)
        db.session.add(the_user)
        db.session.commit()
        flash(u'Приветствуем, ' + form.name.data + '!', 'success')
        login_user(the_user)
        return redirect(request.args.get('next') or url_for('main.index'))
    return render_template('register.html', form=form, title=u"Зарегистрироваться")


@auth.route('/change_password/', methods=['GET', 'POST'])
@login_required  # Обработка смены пароля пользователя
def change_password():
    form = ChangePasswordForm()
    if form.validate_on_submit():
        current_user.password = form.new_password.data
        db.session.add(current_user)
        db.session.commit()
        flash(u'Пароль успешно изменён!', 'info')
        return redirect(url_for('user.detail', user_id=current_user.id))
    return render_template('user_edit.html', form=form, user=current_user, title=u"Сменить пароль")


@book.route('/')
def index():  # Обработка списка всех книг и поиска книг
    search_word = request.args.get('search', None)
    search_form = SearchForm()
    page = request.args.get('page', 1, type=int)

    the_books = Book.query
    if not current_user.can(Permission.UPDATE_BOOK_INFORMATION):
        the_books = Book.query.filter_by(hidden=0)

    if search_word:
        search_word = search_word.strip()
        the_books = the_books.filter(db.or_(
            Book.title.ilike(u"%%%s%%" % search_word), Book.author.ilike(u"%%%s%%" % search_word), Book.isbn.ilike(
                u"%%%s%%" % search_word), Book.subtitle.ilike(
                u"%%%s%%" % search_word))).outerjoin(Log).group_by(Book.id).order_by(db.func.count(Log.id).desc())
        search_form.search.data = search_word
    else:
        the_books = Book.query.order_by(Book.id.desc())

    pagination = the_books.paginate(page, per_page=8)
    result_books = pagination.items
    return render_template("book.html", books=result_books, pagination=pagination, search_form=search_form,
                           title=u"Список книг")


@book.route('/<book_id>/')
def detail(book_id):  # Обработка информации о книге
    the_book = Book.query.get_or_404(book_id)

    if the_book.hidden and (not current_user.is_authenticated or not current_user.is_administrator()):
        abort(404)

    show = request.args.get('show', 0, type=int)
    page = request.args.get('page', 1, type=int)
    form = CommentForm()

    if show in (1, 2):
        pagination = the_book.logs.filter_by(returned=show - 1) \
            .order_by(Log.borrow_timestamp.desc()).paginate(page, per_page=5)
    else:
        pagination = the_book.comments.filter_by(deleted=0) \
            .order_by(Comment.edit_timestamp.desc()).paginate(page, per_page=5)

    data = pagination.items
    return render_template("book_detail.html", book=the_book, data=data, pagination=pagination, form=form,
                           title=the_book.title)


@book.route('/<int:book_id>/edit/', methods=['GET', 'POST'])
@permission_required(Permission.UPDATE_BOOK_INFORMATION)  # Обработка изменения информации о книге
def edit(book_id):
    book = Book.query.get_or_404(book_id)
    form = EditBookForm()
    if form.validate_on_submit():
        book.isbn = form.isbn.data
        book.title = form.title.data
        book.subtitle = form.subtitle.data
        book.author = form.author.data
        book.image = form.image.data
        book.pubdate = form.pubdate.data
        book.pages = form.pages.data
        book.numbers = form.numbers.data
        book.summary = form.summary.data
        db.session.add(book)
        db.session.commit()
        flash(u'Изменения сохранены', 'success')
        return redirect(url_for('book.detail', book_id=book_id))
    form.isbn.data = book.isbn
    form.title.data = book.title
    form.subtitle.data = book.subtitle
    form.author.data = book.author
    form.image.data = book.image
    form.pubdate.data = book.pubdate
    form.pages.data = book.pages
    form.numbers.data = book.numbers
    form.summary.data = book.summary or ""
    return render_template("book_edit.html", form=form, book=book, title=u"Изменение данных книги")


@book.route('/add/', methods=['GET', 'POST'])
@permission_required(Permission.ADD_BOOK)  # Обработка добавления новой книги
def add():
    form = AddBookForm()
    form.numbers.data = 3
    if form.validate_on_submit():
        new_book = Book(
            isbn=form.isbn.data,
            title=form.title.data,
            subtitle=form.subtitle.data,
            author=form.author.data,
            image=form.image.data,
            pubdate=form.pubdate.data,
            pages=form.pages.data,
            numbers=form.numbers.data,
            summary=form.summary.data or "")
        db.session.add(new_book)
        db.session.commit()
        flash(u'Книга ' + new_book.title + ' была добавлена в бибилотеку', 'success')
        return redirect(url_for('book.detail', book_id=new_book.id))
    return render_template("book_edit.html", form=form, title=u"Добавление книги")


@book.route('/<int:book_id>/delete/')
@permission_required(Permission.DELETE_BOOK)  # Обработка удаления книги
def delete(book_id):
    the_book = Book.query.get_or_404(book_id)
    the_book.hidden = 1
    db.session.add(the_book)
    db.session.commit()
    flash(u'Книга удалена! Пользователи больше не могут просматривать данное произведение', 'info')
    return redirect(request.args.get('next') or url_for('book.detail', book_id=book_id))


@book.route('/<int:book_id>/put_back/')
@admin_required  # Обработка восстановления удалённой книги
def put_back(book_id):
    the_book = Book.query.get_or_404(book_id)
    the_book.hidden = 0
    db.session.add(the_book)
    db.session.commit()
    flash(u'Пользователи снова могут просматривать эту книгу', 'info')
    return redirect(request.args.get('next') or url_for('book.detail', book_id=book_id))


@comment.route('/add/<int:book_id>/', methods=['POST', ])
@login_required  # Обработка добавления комментария
@permission_required(Permission.WRITE_COMMENT)
def add(book_id):
    form = CommentForm()
    the_book = Book.query.get_or_404(book_id)
    if the_book.hidden and not current_user.is_administrator():
        abort(404)

    if form.validate_on_submit():
        the_comment = Comment(user=current_user, book=the_book, comment=form.comment.data)
        db.session.add(the_comment)
        db.session.commit()
        flash(u'Рецензия опубликована', 'success')
    return redirect(request.args.get('next') or url_for('book.detail', book_id=book_id))


@comment.route('/delete/<int:comment_id>')
@login_required  # Обработка удаления комментария
def delete(comment_id):
    the_comment = Comment.query.get_or_404(comment_id)
    if current_user.id == the_comment.user_id or current_user.can(Permission.DELETE_OTHERS_COMMENT):
        the_comment.deleted = 1
        book_id = the_comment.book_id
        db.session.add(the_comment)
        db.session.commit()
        flash(u'Рецензия удалена', 'info')
        return redirect(request.args.get('next') or url_for('book.detail', book_id=book_id))
    else:
        abort(403)


@log.route('/borrow/')
@login_required  # Обработка заимствования книги
@permission_required(Permission.BORROW_BOOK)
def book_borrow():
    book_id = request.args.get('book_id')
    the_book = Book.query.get_or_404(book_id)
    if the_book.hidden and not current_user.is_administrator():
        abort(404)

    result, message = current_user.borrow_book(the_book)
    flash(message, 'success' if result else 'danger')
    db.session.commit()
    return redirect(request.args.get('next') or url_for('book.detail', book_id=book_id))


@log.route('/return/')
@login_required  # Обработка возврата книги
@permission_required(Permission.RETURN_BOOK)
def book_return():
    log_id = request.args.get('log_id')
    book_id = request.args.get('book_id')
    the_log = None
    if log_id:
        the_log = Log.query.get(log_id)
    if book_id:
        the_log = Log.query.filter_by(user_id=current_user.id, book_id=book_id).first()
    if log is None:
        flash(u'Запись не найдена', 'warning')
    else:
        result, message = current_user.return_book(the_log)
        flash(message, 'success' if result else 'danger')
        db.session.commit()
    return redirect(request.args.get('next') or url_for('book.detail', book_id=log_id))


@log.route('/')
@login_required  # Обработка истории взятых книг
def index():
    show = request.args.get('show', 0, type=int)
    if show != 0:
        show = 1

    page = request.args.get('page', 1, type=int)
    pagination = Log.query.filter_by(returned=show).order_by(Log.borrow_timestamp.desc()).paginate(page, per_page=10)
    logs = pagination.items
    return render_template("logs_info.html", logs=logs, pagination=pagination, title=u"История взятых книг")


@user.route('/')
@login_required  # Обработка списка зарегистрированных пользователей
def index():
    page = request.args.get('page', 1, type=int)
    pagination = User.query.order_by(User.id.desc()).paginate(page, per_page=10)
    users = pagination.items
    return render_template("user.html", users=users, pagination=pagination, title=u"Зарегистрированные пользователи")


@user.route('/<int:user_id>/')  # Обработка информации об аккаунте пользователя
def detail(user_id):
    the_user = User.query.get_or_404(user_id)

    show = request.args.get('show', 0, type=int)
    if show != 0:
        show = 1

    page = request.args.get('page', 1, type=int)
    pagination = the_user.logs.filter_by(returned=show) \
        .order_by(Log.borrow_timestamp.desc()).paginate(page, per_page=5)
    logs = pagination.items

    return render_template("user_detail.html", user=the_user, logs=logs, pagination=pagination,
                           title=u"Пользователь: " + the_user.name)


@user.route('/<int:user_id>/edit/', methods=['GET', 'POST'])
@login_required  # Обработка изменения данных аккаунта
def edit(user_id):
    if current_user.id == user_id:
        the_user = User.query.get_or_404(user_id)
        form = EditProfileForm()
        if form.validate_on_submit():
            the_user.name = form.name.data
            the_user.major = form.major.data
            the_user.headline = form.headline.data
            the_user.about_me = form.about_me.data
            db.session.add(the_user)
            db.session.commit()
            flash(u'Данные сохранены', "info")
            return redirect(url_for('user.detail', user_id=user_id))
        form.name.data = the_user.name
        form.major.data = the_user.major
        form.headline.data = the_user.headline
        form.about_me.data = the_user.about_me

        return render_template('user_edit.html', form=form, user=the_user, title=u"Редактирование данных")
    else:
        abort(403)


@user.route('/<int:user_id>/avatar_edit/', methods=['GET', 'POST'])
@login_required  # Обработка изменения аватара пользователя
def avatar(user_id):
    if current_user.id == user_id:
        the_user = User.query.get_or_404(user_id)
        avatar_upload_form = AvatarUploadForm()
        if avatar_upload_form.validate_on_submit():
            if 'avatar' in request.files:
                forder = str(user_id)
                avatar_name = avatars.save(avatar_upload_form.avatar.data, folder=forder)
                the_user.avatar = json.dumps({"use_out_url": False, "url": avatar_name})
                db.session.add(the_user)
                db.session.commit()
                flash(u'Аватар изменён', 'success')
                return redirect(url_for('user.detail', user_id=user_id))
        return render_template('avatar_edit.html', user=the_user,
                               avatar_upload_form=avatar_upload_form, title=u"Изменить аватар")
    else:
        abort(403)


@main.app_context_processor
def inject_permissions():  # Обработка доступных действий
    return dict(Permission=Permission)


@main.route('/')
def index():  # Обработка главной страницы сайта
    the_books = Book.query
    if not current_user.can(Permission.UPDATE_BOOK_INFORMATION):
        the_books = the_books.filter_by(hidden=0)
    popular_books = the_books.outerjoin(Log).group_by(Book.id).order_by(db.func.count(Log.id).desc()).limit(5)
    popular_users = User.query.outerjoin(Log).group_by(User.id).order_by(db.func.count(Log.id).desc()).limit(6)
    recently_comments = Comment.query.filter_by(deleted=0).order_by(Comment.edit_timestamp.desc()).limit(5)
    return render_template("index.html", books=popular_books, users=popular_users, recently_comments=recently_comments)
