from flask import Blueprint

auth = Blueprint('auth', __name__, template_folder='templates')
book = Blueprint('book', __name__, url_prefix='/books', template_folder='templates')
comment = Blueprint('comment', __name__, url_prefix='/comments')
log = Blueprint('log', __name__, url_prefix='/logs_info', template_folder='templates')
user = Blueprint('user', __name__, url_prefix='/users', template_folder='templates')
main = Blueprint('main', __name__, template_folder='templates')
from . import views
