from app import db
from app.models import Book, User
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, IntegerField, ValidationError, PasswordField, BooleanField, TextAreaField
from wtforms.validators import Length, DataRequired, Email, EqualTo, Regexp
from flask_pagedown.fields import PageDownField
from flask_wtf.file import FileField, FileAllowed
from app import avatars


class LoginForm(FlaskForm):  # Авторизация пользователя
    email = StringField('Почта',
                        validators=[DataRequired(message=u"Зполните это поле!"), Length(1, 64),
                                    Email(message=u"Некорректная почта")])
    password = PasswordField(u'Пароль', validators=[DataRequired(message=u"Зполните это поле!"), Length(6, 32)])
    remember_me = BooleanField(u"Запомнить меня", default=True)
    submit = SubmitField(u'Войти')


class RegistrationForm(FlaskForm):  # Регистрация пользователя
    email = StringField('Почта',
                        validators=[DataRequired(message=u"Зполните это поле!"), Length(1, 64),
                                    Email(message=u"Некорректная почта")])
    name = StringField(u'Логин', validators=[DataRequired(message=u"Зполните это поле!"), Length(1, 64)])
    password = PasswordField(u'Пароль',
                             validators=[DataRequired(message=u"Зполните это поле!"),
                                         EqualTo('password2', message=u'Пароли не совпадают'),
                                         Length(6, 32)])
    password2 = PasswordField(u'Повторите пароль', validators=[DataRequired(message=u"Зполните это поле!")])
    submit = SubmitField(u'Зарегистрироваться')

    def validate_email(self, filed): # Проверка зарегистрирована ли почта
        if User.query.filter(db.func.lower(User.email) == db.func.lower(filed.data)).first():
            raise ValidationError(u'Эта почта уже зарегистрирована')


class ChangePasswordForm(FlaskForm):  # Смена пароля
    old_password = PasswordField(u'Старый пароль', validators=[DataRequired(message=u"Зполните это поле!")])
    new_password = PasswordField(u'Новый пароль', validators=[DataRequired(message=u"Зполните это поле!"),
                                                              EqualTo('confirm_password',
                                                                      message=u'Пароли не совпадают'),
                                                              Length(6, 32)])
    confirm_password = PasswordField(u'Повторите новый пароль',
                                     validators=[DataRequired(message=u"Зполните это поле!")])
    submit = SubmitField(u"Сохранить пароль")

    def validate_old_password(self, filed): # Проверка на правильность ввода старого пароля
        from flask_login import current_user
        if not current_user.verify_password(filed.data):
            raise ValidationError(u'Старый пароль введён неверно')


class EditBookForm(FlaskForm):  # Изменение данных о книге
    isbn = StringField(u"ISBN",
                       validators=[DataRequired(message=u"Заполните это поле!"),
                                   Regexp('[0-9]{13,13}', message=u"ISBN должен быть 13-значным числом")])
    title = StringField(u"Название книги",
                        validators=[DataRequired(message=u"Заполните это поле!"),
                                    Length(1, 128, message=u"От 1 до 128 символов")])
    subtitle = StringField(u"Подзаголовок", validators=[Length(0, 128, message=u"От 0 до 128 символов")])
    author = StringField(u"Автор", validators=[Length(0, 128, message=u"От 0 до 64 символов")])
    image = StringField(u"Оболжка(URL ссылка на фотографию)",
                        validators=[Length(0, 128, message=u"От 0 до 128 символов")])
    pubdate = StringField(u"Дата публикации книги", validators=[Length(0, 32, message=u"От 0 до 32 символов")])
    pages = IntegerField(u"Количество страниц")
    numbers = IntegerField(u"Всего доступно", validators=[DataRequired(message=u"Заполните это поле!")])
    summary = PageDownField(u"Краткое описание")
    submit = SubmitField(u"Сохранить изменения")


class AddBookForm(EditBookForm):  # Добавление книги
    def validate_isbn(self, filed): # Проверка на существвующий ISBN книги
        if Book.query.filter_by(isbn=filed.data).count():
            raise ValidationError(u'ISBN уже существует, пожалуйста, перепроверьте')


class SearchForm(FlaskForm):  # Поиск книг
    search = StringField(validators=[DataRequired()])
    submit = SubmitField(u"Поиск")


class CommentForm(FlaskForm):  # Обзор на книгу
    comment = TextAreaField(u"Рецензия на книгу",
                            validators=[DataRequired(message=u"Комментарий не может быть пустым"),
                                        Length(1, 1024, message=u"Длина рецензии ограничена 1024 символами")])
    submit = SubmitField(u"Опубликовать")


class EditProfileForm(FlaskForm):  # Изменение данных пользователя
    name = StringField(u'Логин', validators=[DataRequired(message=u"Зполните это поле!"),
                                             Length(1, 64, message=u"От 1 до 64 символов")])
    major = StringField(u'Роль', validators=[Length(0, 128, message=u"От 0 до 128 символов")])
    headline = StringField(u'Подзаголовок', validators=[Length(0, 32, message=u"До 32 символов")])
    about_me = PageDownField(u"О себе")
    submit = SubmitField(u"Сохранить изменения")


class AvatarUploadForm(FlaskForm):  # Изменение аватара пользователя
    avatar = FileField('', validators=[FileAllowed(avatars, message=u"Загрузить фотографию")])
