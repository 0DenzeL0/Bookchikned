from app.models import Book as model_Book
from app.models import Comment as model_Comment
from .fields import comment_detail_fields, comment_list, book_detail_fields, book_list, logs_info_detail_fields, \
    logs_info_list, user_detail_fields, user_list
from app.models import Log as model_Log
from app.models import User as model_User
from flask import url_for
from flask_restful import Resource, marshal_with, abort
from . import api, parser, default_per_page


@api.route('/books/<int:book_id>/')
class Book(Resource):  # Книга
    @marshal_with(book_detail_fields)
    def get(self, book_id):
        book = model_Book.query.get_or_404(book_id)
        if book.hidden:
            abort(404)
        return book


@api.route('/books/')
class BookList(Resource):  # Список книг
    @marshal_with(book_list)
    def get(self):
        args = parser.parse_args()
        page = args['page'] or 1
        per_page = args['per_page'] or default_per_page
        pagination = model_Book.query.paginate(page=page, per_page=per_page)
        items = pagination.items
        prev = None
        if pagination.has_prev:
            prev = url_for('api.booklist', page=page - 1, count=per_page, _external=True)
        next = None
        if pagination.has_next:
            next = url_for('api.booklist', page=page + 1, count=per_page, _external=True)
        return {
            'items': items,
            'prev': prev,
            'next': next,
            'total': pagination.total,
            'pages_count': pagination.pages,
            'current_page': pagination.page,
            'per_page': per_page,
        }


@api.route('/comments/<int:comment_id>/')
class Comment(Resource):  # Комметарий
    @marshal_with(comment_detail_fields)
    def get(self, comment_id):
        comment = model_Comment.query.get_or_404(comment_id)
        if comment.deleted:
            abort(404)
        return comment


@api.route('/comments/')
class CommentList(Resource):  # Список комментариев
    @marshal_with(comment_list)
    def get(self):
        parser.add_argument('book_id', type=int, location='args')
        parser.add_argument('user_id', type=int, location='args')
        parser.add_argument('deleted', type=int, location='args')
        args = parser.parse_args()
        page = args['page'] or 1
        per_page = args['per_page'] or default_per_page
        comment_query = model_Comment.query

        user_id = args['user_id']
        book_id = args['book_id']

        deleted = 0

        if user_id is not None:
            comment_query = comment_query.filter_by(user_id=user_id)
        if book_id is not None:
            comment_query = comment_query.filter_by(book_id=book_id)
        if deleted is not None:
            comment_query = comment_query.filter_by(deleted=deleted)

        pagination = comment_query.order_by(model_Comment.id.desc()).paginate(page=page, per_page=per_page)
        items = pagination.items
        prev = None
        if pagination.has_prev:
            prev = url_for('api.commentlist', page=page - 1, per_page=per_page, _external=True)
        next = None
        if pagination.has_next:
            next = url_for('api.commentlist', page=page + 1, per_page=per_page, _external=True)
        return {
            'items': items,
            'prev': prev,
            'next': next,
            'total': pagination.total,
            'pages_count': pagination.pages,
            'current_page': pagination.page,
            'per_page': per_page,
        }


@api.route('/logs_info/<int:log_id>/')
class Log(Resource):  # История взаймодействия с книгами
    @marshal_with(logs_info_detail_fields)
    def get(self, log_id):
        return model_Log.query.get_or_404(log_id)


@api.route('/logs_info/')
class LogList(Resource):  # Список историй взаймодействия с книгами
    @marshal_with(logs_info_list)
    def get(self):
        parser.add_argument('user_id', type=int, location='args')
        parser.add_argument('book_id', type=int, location='args')
        parser.add_argument('returned', type=int, location='args')
        args = parser.parse_args()
        page = args['page'] or 1
        per_page = args['per_page'] or default_per_page
        log_query = model_Log.query
        user_id = args['user_id']
        book_id = args['book_id']
        returned = args['returned']
        if user_id is not None:
            log_query = log_query.filter_by(user_id=user_id)
        if book_id is not None:
            log_query = log_query.filter_by(book_id=book_id)
        if returned is not None:
            log_query = log_query.filter_by(returned=returned)
        pagination = log_query.paginate(page=page, per_page=per_page)
        items = pagination.items
        prev = None
        if pagination.has_prev:
            prev = url_for('api.loglist', page=page - 1, per_page=per_page, _external=True)
        next = None
        if pagination.has_next:
            next = url_for('api.loglist', page=page + 1, per_page=per_page, _external=True)
        return {
            'items': items,
            'prev': prev,
            'next': next,
            'total': pagination.total,
            'pages_count': pagination.pages,
            'current_page': pagination.page,
            'per_page': per_page
        }


@api.route('/users/<int:user_id>/')
class User(Resource):  # Пользователь
    @marshal_with(user_detail_fields)
    def get(self, user_id):
        user = model_User.query.get_or_404(user_id)
        user.uri = url_for('api.user', user_id=user_id, _external=True)
        return user


@api.route('/users/')
class UserList(Resource):  # Список пользователей
    @marshal_with(user_list)
    def get(self):
        args = parser.parse_args()
        page = args['page'] or 1
        per_page = args['per_page'] or default_per_page
        pagination = model_User.query.order_by(model_User.id.desc()).paginate(page=page, per_page=per_page)
        items = pagination.items
        prev = None
        if pagination.has_prev:
            prev = url_for('api.userlist', page=page - 1, per_page=per_page, _external=True)
        next = None
        if pagination.has_next:
            next = url_for('api.userlist', page=page + 1, per_page=per_page, _external=True)
        return {
            'items': items,
            'prev': prev,
            'next': next,
            'total': pagination.total,
            'pages_count': pagination.pages,
            'current_page': pagination.page,
            'per_page': per_page
        }
